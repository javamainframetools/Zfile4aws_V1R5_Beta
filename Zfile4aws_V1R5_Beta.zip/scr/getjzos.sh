#!/bin/bash

rootdir=LX_dir
zoshost=ZH_ipadr
zosjavapath=/usr/lpp/java/J8.0_64/lib/ext
user=$1
password=$2


ftp -inv $zoshost <<EOF
user $user $password
lcd $rootdir/lib
cd $zosjavapath
bin
get ibmjzos.jar
get ibmjceprovider.jar
get ibmjcecca.jar
bye
EOF

