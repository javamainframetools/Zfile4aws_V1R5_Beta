#!/bin/bash

rootdir=LX_dir
zoshost=ZH_ipadr
user=$1
password=$2


echo "open "$zoshost > putjcl.txt
echo "user "$user" "$password >> putjcl.txt
echo "lcd "$rootdir"/jcls" >> putjcl.txt
echo "bin" >> putjcl.txt
echo "quote SITE BLK=80 LR=80 REC=F CY PRI=1" >> putjcl.txt
echo "put xmitjcl XMITJCL" >> putjcl.txt
echo "bye" >> putjcl.txt

ftp -n < putjcl.txt
rm putjcl.txt



