#!/bin/bash

rootdir=LX_dir
conf=$rootdir"/conf/Config_file_name_onlinux"


parms=$1
confp=$2

if [ -z "$confp" ]
then
      :
else
      conf=$confp
fi

for i in "${rootdir}"/lib/*.jar; do
    CLASSPATH="$CLASSPATH":"$i"
    done

export CLASSPATH="$CLASSPATH"
export Zfile4aws_cfg="$conf"
export Zfile4aws_opt="r"

java -cp "$CLASSPATH" PackV1R5.zfilemain $parms

