#!/bin/bash

rootdir=LX_dir
zoshost=ZH_ipadr
zosrootdir=ZH_dir
user=$1
password=$2


echo "open "$zoshost > putaws.txt
echo "user "$user" "$password >> putaws.txt
echo "lcd "$rootdir"/lib" >> putaws.txt
echo "cd "$zosrootdir"/lib" >> putaws.txt
echo "bin" >> putaws.txt
for i in "${rootdir}"/lib/*.jar; do
    filen=`basename "$i"`
    echo "put "$filen" " >> putaws.txt
    done
echo "lcd "$rootdir"/bin" >> putaws.txt  
echo "cd "$zosrootdir"/bin" >> putaws.txt
echo "put libcallospgm.so" >> putaws.txt
echo "lcd "$rootdir"/conf" >> putaws.txt  
echo "cd "$zosrootdir"/conf" >> putaws.txt
echo "prompt" >> putaws.txt
echo "mput Ex*" >> putaws.txt
echo "mput auth*" >> putaws.txt
echo "bye" >> putaws.txt

ftp -n < putaws.txt 
rm putaws.txt




